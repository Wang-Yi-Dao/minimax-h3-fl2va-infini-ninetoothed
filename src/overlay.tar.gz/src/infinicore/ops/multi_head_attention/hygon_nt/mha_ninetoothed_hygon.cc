// Fused attention for HYGON (DCU) on top of the upstream nine-toothed flash-attention
// kernel. This file is compiled only when the hygon nine-toothed flash-attention
// registration is enabled, so it never clashes with the ATen based
// mha_flashattn_hygon.cc path.
#if defined(ENABLE_HYGON_API) && defined(ENABLE_NINETOOTHED) && defined(INFINIOP_HYGON_NINETOOTHED_FLASH_ATTENTION)

#include "infinicore/ops/mha.hpp"

#include "infinicore/ops/flash_attention.hpp"

#include <cstdlib>
#include <cstdint>
#include <stdexcept>

#include <limits>
#include "infinicore/adaptor/aten_adaptor.hpp"
// CAUSAL_HELPER includes
namespace infinicore::op::mha_impl::ninetoothed {

namespace {

// The nine-toothed flash-attention kernel walks the tensors as [B, H, S, D]
// (dim -1 is the head dim), while op::mha is called with [B, S, H, D] tensors
// by every model in InfiniLM. Instead of paying a transpose + copy per layer we
// hand the kernel a strided view over the very same buffer.
Tensor head_major_view(const Tensor &tensor) {
    const auto shape = tensor->shape();
    const auto strides = tensor->strides();

    if (shape.size() != 4) {
        throw std::runtime_error("mha (ninetoothed/hygon): expected a 4D tensor");
    }

    Shape view_shape{shape[0], shape[2], shape[1], shape[3]};
    Strides view_strides{strides[0], strides[2], strides[1], strides[3]};

    return Tensor::strided_from_blob(
        const_cast<void *>(static_cast<const void *>(tensor->data())),
        view_shape, view_strides, tensor->dtype(), tensor->device());
}

// The kernel reads the packed kv length from a device side int32 scalar.
Tensor make_total_kv_len(const Tensor &k) {
    const int32_t total = static_cast<int32_t>(k->size(1));  // [B,S,H,D] -> S

    Tensor host = Tensor::empty({1}, DataType::I32, Device(Device::Type::CPU));
    *reinterpret_cast<int32_t *>(host->data()) = total;

    return host->to(k->device());
}

} // namespace

struct PlannedMeta {
    graph::GraphTensor out, q, k, v, total_kv_len;
    float scale;
    bool is_causal;
};

void *plan(Tensor out,
           const Tensor &q,
           const Tensor &k,
           const Tensor &v,
           std::optional<Tensor> alibi_slopes,
           float scale,
           bool is_causal) {
    if (alibi_slopes.has_value()) {
        throw std::runtime_error("mha (ninetoothed/hygon): alibi slopes are not supported");
    }

    if (q->size(2) != k->size(2)) {
        throw std::runtime_error("mha (ninetoothed/hygon): grouped-query attention is not wired yet");
    }

    return new PlannedMeta{
        graph::GraphTensor(out),
        graph::GraphTensor(q),
        graph::GraphTensor(k),
        graph::GraphTensor(v),
        graph::GraphTensor(make_total_kv_len(k)),
        scale,
        is_causal};
}

// CAUSAL_HELPER: is_causal=True has no ninetoothed kernel -> ATen fallback.
namespace h3_causal_detail {
inline void run_causal_attention(const graph::GraphTensor &out_g,
                                 const graph::GraphTensor &q_g,
                                 const graph::GraphTensor &k_g,
                                 const graph::GraphTensor &v_g,
                                 float scale,
                                 bool is_causal) {
#if INFINICORE_TORCH_VERSION_GE_2_11
    c10::cuda::CUDAStreamGuard guard(infinicore::adaptor::get_hip_stream());
#else
    c10::hip::HIPStreamGuard guard(infinicore::adaptor::get_hip_stream());
#endif
    Tensor out(out_g), q(q_g), k(k_g), v(v_g);
    auto qa = infinicore::adaptor::to_aten_tensor(q);
    auto ka = infinicore::adaptor::to_aten_tensor(k);
    auto va = infinicore::adaptor::to_aten_tensor(v);
    const bool need_copy = !out->is_contiguous();
    Tensor out_w = need_copy ? out->contiguous() : Tensor(out);
    auto oa = infinicore::adaptor::to_aten_tensor(out_w);
    const int64_t nq = qa.size(2);
    const int64_t nkv = ka.size(2);
    at::Tensor k2 = ka;
    at::Tensor v2 = va;
    if (nkv != nq && nkv > 0) {
        const int64_t rep = nq / nkv;
        k2 = ka.unsqueeze(3).repeat({1, 1, 1, rep, 1}).reshape(qa.sizes());
        v2 = va.unsqueeze(3).repeat({1, 1, 1, rep, 1}).reshape(qa.sizes());
    }
    auto w = at::matmul(qa.permute({0, 2, 1, 3}), k2.permute({0, 2, 3, 1})) * scale;
    if (is_causal) {
        auto mask = at::tril(at::ones_like(w), -1).flip({-2, -1});
        auto neg = at::full_like(w, -std::numeric_limits<float>::infinity());
        w = at::where(mask == 1, neg, w);
    }
    auto sm = at::softmax(w, -1);
    auto res = at::matmul(sm, v2.permute({0, 2, 1, 3})).permute({0, 2, 1, 3});
    oa.copy_(res);
    if (need_copy) {
        out->copy_from(out_w);
    }
}
} // namespace h3_causal_detail

// SAFE_FA_HELPER: never let an unsupported shape kill the ranks.
namespace h3_safe_fa_detail {
inline void safe_flash_attention(const Tensor &out,
                                 const Tensor &q,
                                 const Tensor &k,
                                 const Tensor &v,
                                 const Tensor &total_kv_len,
                                 float scale,
                                 bool is_causal) {
    try {
        op::flash_attention_(out, q, k, v, total_kv_len, scale, is_causal);
        return;
    } catch (const std::exception &) {
    } catch (...) {
    }
    h3_causal_detail::run_causal_attention(out, q, k, v, scale, is_causal);
}
} // namespace h3_safe_fa_detail

// PAD80_HELPER: zero-pad head_dim to 128 when no ninetoothed kernel covers it.
namespace h3_pad80_detail {
inline void run_padded_attention(const graph::GraphTensor &out_g,
                                 const graph::GraphTensor &q_g,
                                 const graph::GraphTensor &k_g,
                                 const graph::GraphTensor &v_g,
                                 const graph::GraphTensor &len_g,
                                 float scale,
                                 bool is_causal) {
    Tensor out(out_g), q(q_g), k(k_g), v(v_g), tkl(len_g);
    const Shape qs = q->shape();
    const Strides sq = q->strides();
    const Strides sk = k->strides();
    const Strides sv = v->strides();
    const Strides so = out->strides();
    const Size B = qs[0];
    const Size S = qs[1];
    const Size H = qs[2];
    const Size D = qs[3];
    const Size PAD = 128;
    Tensor qh = q->as_strided(Shape{B, H, S, D}, Strides{sq[0], sq[2], sq[1], sq[3]});
    Tensor kh = k->as_strided(Shape{B, H, S, D}, Strides{sk[0], sk[2], sk[1], sk[3]});
    Tensor vh = v->as_strided(Shape{B, H, S, D}, Strides{sv[0], sv[2], sv[1], sv[3]});
    Tensor oh = out->as_strided(Shape{B, H, S, D}, Strides{so[0], so[2], so[1], so[3]});
    Tensor qp = Tensor::zeros(Shape{B, H, S, PAD}, q->dtype(), q->device());
    Tensor kp = Tensor::zeros(Shape{B, H, S, PAD}, k->dtype(), k->device());
    Tensor vp = Tensor::zeros(Shape{B, H, S, PAD}, v->dtype(), v->device());
    Tensor op = Tensor::zeros(Shape{B, H, S, PAD}, out->dtype(), out->device());
    qp->narrow({{3, 0, D}})->copy_from(qh);
    kp->narrow({{3, 0, D}})->copy_from(kh);
    vp->narrow({{3, 0, D}})->copy_from(vh);
    h3_safe_fa_detail::safe_flash_attention(op, qp, kp, vp, tkl, scale, is_causal);
    oh->copy_from(op->narrow({{3, 0, D}}));
}
} // namespace h3_pad80_detail

void run(void *planned_meta) {
    auto *p = reinterpret_cast<PlannedMeta *>(planned_meta);
    // P52_FORCE_ATEN: env-gated ATen reference path (A/B bisect of the fused kernel)
    if (std::getenv("H3_FORCE_ATEN_ATTN") != nullptr) {
        h3_causal_detail::run_causal_attention(p->out, p->q, p->k, p->v,
                                              static_cast<float>(p->scale), p->is_causal);
        return;
    }

    // CAUSAL_GUARD
    if (p->is_causal) {
        h3_causal_detail::run_causal_attention(p->out, p->q, p->k, p->v,
                                               static_cast<float>(p->scale), p->is_causal);
        return;
    }
    // PAD80_GUARD: head_dim without a ninetoothed kernel -> padded 128 path
    if (p->out->shape()[3] != 72 && p->out->shape()[3] != 128) {
        h3_pad80_detail::run_padded_attention(p->out, p->q, p->k, p->v, p->total_kv_len,
                                             static_cast<float>(p->scale), p->is_causal);
        return;
    }


    auto q = head_major_view(p->q);
    auto k = head_major_view(p->k);
    auto v = head_major_view(p->v);
    auto out = head_major_view(p->out);

    h3_safe_fa_detail::safe_flash_attention(out, q, k, v, p->total_kv_len, p->scale, p->is_causal);
}

void cleanup(void **planned_meta_ptr) {
    delete *reinterpret_cast<PlannedMeta **>(planned_meta_ptr);
    *planned_meta_ptr = nullptr;
}

static bool registered = []() {
    MultiheadAttention::plan_dispatcher().registerDevice(Device::Type::HYGON, &plan);
    MultiheadAttention::run_dispatcher().registerDevice(Device::Type::HYGON, &run);
    MultiheadAttention::cleanup_dispatcher().registerDevice(Device::Type::HYGON, &cleanup);
    return true;
}();

} // namespace infinicore::op::mha_impl::ninetoothed

#endif // ENABLE_HYGON_API && ENABLE_NINETOOTHED && INFINIOP_HYGON_NINETOOTHED_FLASH_ATTENTION
