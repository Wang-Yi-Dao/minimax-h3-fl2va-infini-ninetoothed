import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import infinicore
import torch
from framework import (
    BaseOperatorTest,
    TensorSpec,
    TestCase,
    GenericTestRunner,
    is_broadcast,
)

# =======================================================================
# Test cases format: (shape, input_strides_or_None)
# =======================================================================

_TEST_CASES_DATA = [
    ((13, 4), None),
    ((13, 4), (10, 1)),
    ((8, 16), None),
    ((8, 16), (40, 1)),
    ((2, 3, 4), None),
    ((16, 5632), None),
]

_TOLERANCE_MAP = {
    infinicore.float16: {"atol": 1e-2, "rtol": 1e-2},
    infinicore.float32: {"atol": 1e-5, "rtol": 1e-4},
    infinicore.bfloat16: {"atol": 1e-2, "rtol": 5e-2},
}

_TENSOR_DTYPES = [infinicore.float16, infinicore.bfloat16, infinicore.float32]


def parse_test_cases():
    test_cases = []
    for data in _TEST_CASES_DATA:
        shape = data[0]
        in_strides = data[1] if len(data) > 1 else None

        supports_inplace = not is_broadcast(in_strides)

        for dtype in _TENSOR_DTYPES:
            tol = _TOLERANCE_MAP.get(dtype, {"atol": 1e-5, "rtol": 1e-4})
            input_spec = TensorSpec.from_tensor(shape, in_strides, dtype)
            out_spec = TensorSpec.from_tensor(shape, None, dtype)

            test_cases.append(
                TestCase(
                    inputs=[input_spec],
                    kwargs={},
                    output_spec=None,
                    comparison_target=None,
                    tolerance=tol,
                    description="atanh - OUT_OF_PLACE",
                )
            )

            test_cases.append(
                TestCase(
                    inputs=[input_spec],
                    kwargs=None,
                    output_spec=out_spec,
                    comparison_target="out",
                    tolerance=tol,
                    description="atanh - INPLACE(out)",
                )
            )

            if supports_inplace:
                test_cases.append(
                    TestCase(
                        inputs=[input_spec],
                        kwargs={"out": 0},
                        output_spec=None,
                        comparison_target=0,
                        tolerance=tol,
                        description="atanh - INPLACE(input)",
                    )
                )

    return test_cases


class OpTest(BaseOperatorTest):
    """Atanh operator test with simplified implementation"""

    def __init__(self):
        super().__init__("Atanh")

    def get_test_cases(self):
        return parse_test_cases()

    def torch_operator(self, *args, **kwargs):
        return torch.atanh(*args, **kwargs)

    def infinicore_operator(self, *args, **kwargs):
        """InfiniCore atanh implementation"""
        return infinicore.atanh(*args, **kwargs)


def main():
    """Main entry point"""
    runner = GenericTestRunner(OpTest)
    runner.run_and_exit()


if __name__ == "__main__":
    main()
